
######################################################## NALOGA 1 #################################################################################
ciklov = scan(file = "vzorec64190391.txt", sep = " ", skip = 4, nlines = 4)
n = length(ciklov)

m = mean(ciklov) 
m
s = sd(ciklov)
s

min = min(ciklov)
maks = max(ciklov)

min
maks

hist(ciklov, breaks = sqrt(n), probability = TRUE, main = "Število ciklov polnenja/praznenja", xlab = "Število ciklov", ylab = "Verjetnost", col = "lightgreen", ylim = c(0, 0.007))

x = seq(600,1000, by = 1)
y = dnorm(x, m, s) #probability density function

lines(x, y, col = "red")

#Goodnes of fit test
source("gof.r")
gof(ciklov, 0.05) #Testna statistika je manjša od primerjalnega kvantila => ne moremo zavrniti H0 => ni dokazov, da ni normalno razdeljen
gof(ciklov, 0.01) #Testna statistika je manjša od primerjalnega kvantila => ne moremo zavrniti H0 => ni dokazov, da ni normalno razdeljen

#Histogram 
hist(ciklov, col = "yellow", main = "Število ciklov polnenja/praznenja", probability = TRUE, xlab = "Število ciklov", ylab = "Verjetnost")

x = seq(600,1000, by = 1)
y = dnorm(x, mean(ciklov), sd(ciklov)) #funkcija gostote verjetnosti



lines(x, y, col = "green")

# Interval zaupanja
interval.norm = function(alpha, povp){ #podaj alpha in povp
  z = qnorm(alpha/2, 0, 1, lower.tail = FALSE) 
  l = povp - z*s/sqrt(n) # spodnja meja
  u = povp + z*s/sqrt(n) # zgornja meja
  
  
  print(paste((1-alpha)*100, "% Interval zaupanja: [" , round(l,2), ",", round(u,2), "]"))
}

interval.norm(0.05, m)
interval.norm(0.01, m)

######################################################## NALOGA 2 #################################################################################

data = read.table(file = "Naloga2.txt", sep = ",", dec = ".", header=TRUE)
data

attach(data)


alpha = 0.05


diff = obogateno - neobogateno
data$diff = diff
xbar = mean(diff)
s = sd(diff)
n2 = length(diff)

#Goodnes of fit test
source("gof.r")
gof(diff, 0.05) #Testna statistika je manjša od primerjalnega kvantila => ne moremo zavrniti H0 => ni dokazov, da ni normalno razdeljen

#Histogram razlike
hist(diff, col = "pink", main = "Histogram razlike", probability = TRUE, xlab = "Razlika med obogateno in neobogateno", ylab = "Verjetnost")

min(diff)
max(diff)
x = seq(-350,1400, by = 1)
y = dnorm(x, mean(diff), sd(diff)) #funkcija gostote verjetnosti

lines(x, y, col = "green")

#Izvedemo parni t-test
#Preizkušanje hipoteze H0: razlika v srednjih vrednostih je 300, mu2-mu1 = 300
#Alternativna hipoteza je H1: večja je od 300, mu2-mu1 > 300
#Če zavrnemo H0 in sprejmemo H1, to pomeni, da je zagotovo stroškovno učinkovit

t1 = t.test(obogateno, neobogateno, mu=300, alternative="greater", paired=TRUE, conf.level = 0.95)
p_value = t1$p.value
p_value < 0.05 
#p-vrednost je manjša od alfe => ZAVRNEMO H0 => OBSTAJAJO MOČNI DOKAZI, DA PRAVA SREDNJA VREDNOST NI ENAKA 300

##### ALI #######
t0 = (xbar-300)/(s/sqrt(n2))
t_perc = qt(alpha, n2-1, lower.tail = FALSE)

t0 > t_perc # Večja kot upper percentage point => zavrnemo H0

######################################################## NALOGA 3 #################################################################################

parametri = read.table(file = "Naloga3.txt", sep = " ", dec = ",", header=TRUE)
parametri

attach(parametri)

# guba - stegno
plot(guba, stegno, xlab = "guba", ylab = "stegno", main = "Guba - Stegno odnos")
reg.line = lm(stegno ~ guba) 
reg.line$coefficients 
abline(reg.line, col = "purple")
cor.test(guba, stegno)
# korelacijski koef = 0.9238425 

# guba - nadlaht
plot(guba, nadlaht, xlab = "guba", ylab = "nadlaht", main = "Guba - Nadlaht odnos")
reg.line = lm(nadlaht ~ guba) 
reg.line$coefficients 
abline(reg.line, col = "orange")
cor.test(guba, nadlaht)
# korelacijski koef = 0.4577772 

# stegno - nadlaht
plot(stegno, nadlaht, xlab = "stegno", ylab = "nadlaht", main = "Stegno - Nadlaht odnos")
reg.line = lm(nadlaht ~ stegno) 
reg.line$coefficients 
abline(reg.line, col = "cyan")
cor.test(stegno, nadlaht)
# korelacijski koef = 0.0846675 

MLR = lm(maščoba ~ guba + stegno + nadlaht) #ne pomeni da se dejansko sestejeta
coef = round(MLR$coefficients,2)
coef
print(paste("maščoba = ", coef[1], "+", coef[2], "*guba + ", coef[3], "*stegno +", coef[4], "*nadlaht"))

################ Vrednotenje #########

# Način 1
res = MLR$residuals
hist(res, main = "Histogram residualov", probability = TRUE, col = "pink")


#Fit normal curve
xbar = mean(res)
s = sd(res)

xx = seq(-4,5, by = 0.001)
yy = dnorm(xx, xbar, s)
lines(xx,yy, col = "blue")

# Način 2
plot(fitted(MLR), res, main="Residual plot")
abline(0,0)

# Način 3
summary(MLR)
# p - vrednost je 7.343e-06 < 0.05

# Napovedi
#a)

# m = 21,7 guba =  25,6 stegno =  53,9 nadlaht =  23,7
guba =  25.6 
stegno =  53.9 
nadlaht =  23.7
m = coef[1] + coef[2] * guba + coef[3] * stegno + coef[4] * nadlaht
m

# m = 11,9 guba = 19,5 stegno =  43,1 nadlaht =  29,1
guba2 =  19.5 
stegno2 =  43.1 
nadlaht2 =  29.1
m2 = coef[1] + coef[2] * guba2 + coef[3] * stegno2 + coef[4] * nadlaht2
m2

# Model 2

MLR = lm(maščoba ~ stegno + nadlaht) #ne pomeni da se dejansko sestejeta
coef = round(MLR$coefficients,2)
coef
print(paste("maščoba = ", coef[1], "+", coef[2], "*stegno +", coef[2], "*nadlaht"))

######################################################## NALOGA 4 #################################################################################

data4 = read.table(file = "Naloga4.txt", sep = ",", dec = ".", header=TRUE)
data4
attach(data4)

#a) #24 27 27
data4a = as.data.frame(teža.pred-teža.po)
data4a$dieta = dieta
names(data4a)[1] = "popolna.izguba.teže"
detach(data4)
attach(data4a)

#Boxplot of data
par(mfrow=c(1,1))
boxplot(total.weight.loss~dieta,data=data4a, main="Boxplot", xlab="dieta", ylab="popolna izguba teže", col=c("pink", "lightblue", "lightgreen"))
#Tretja dieta je morda nekoliko bolj drugačna od prvih dveh

#Izvajanje neparametričnega testa za ANOVA => Kruskall-Wallis test
#Ne vemo, ali so residuali normalno porazdeljeni

diet1 = subset(data4a[1], subset = diet==1)[,1]
diet2 = subset(data4a[1], subset = diet==2)[,1]
diet3 = subset(data4a[1], subset = diet==3)[,1]

kruskal.test(list(g1=diet1, g2=diet2, g3=diet3))
# p-vrednost je 0.01494 < alpha = 0.05 => zavrnemo H0 => med razredi je velika razlika

#Izvajamo Dunnov test, da ugotovimo, katera je najbolj drugačna
library(dunn.test)
dunn.test(total.weight.loss, dieta) #neprilagojene p-vrednosti za 1-3 in 2-3 so manjše od alfa=0,05
#dieta 1 in 3 se med seboj statistično značilno razlikujeta, prav tako se dieta 2 in 3 med seboj statistično značilno razlikujeta
#=> to pomeni, da se dieta 3 statistično najbolj razlikuje od vseh treh, kot smo videli iz okvirnega prikaza => dieta 3 je najuspešnejša, saj je mediana najvišja (največ izgubljenih kilogramov)

#b)
detach(data4a)
attach(data4)
data4b = as.data.frame((teža.pred-teža.po)/teža.pred)
data4b$dieta = dieta
names(data4b)[1] = "relativna.izguba.teže"
detach(data4)
attach(data4b)

#Boxplot of data
boxplot(relativna.izguba.teže~dieta,data=data4b, main="Boxplot", xlab="dieta", ylab="relativna izguba teže", col=c("pink", "lightblue", "lightgreen"))
#Tretja dieta je morda nekoliko bolj drugačna od prvih dveh

diet1 = subset(data4b[1], subset = diet==1)[,1]
diet2 = subset(data4b[1], subset = diet==2)[,1]
diet3 = subset(data4b[1], subset = diet==3)[,1]

kruskal.test(list(g1=diet1, g2=diet2, g3=diet3)) 
#p-vrednost = 0.02247 je manjša kot alpha = 0.05 => zavrnemo H0 => vsaj en razred je bistveno drugačen od drugih

#Dunn test
dunn.test(relativna.izguba.teže, dieta)
#p-vrednosti za razrede 1-3 in 2-3 so manjše od alfa => razred 3 se bistveno razlikuje od razreda 2 in 3

#Zaključek: V obeh primerih priporočamo tretjo dieto, ki je najučinkovitejša

#Dieto 3 lahko pustimo na strani in znova izvedemo Kruskal-Wallisov test na dieti 2 in 3, da vidimo, ali morda ti dve vplivata na rezultat izgube teže.

#Za popolno izgubo teže
data4a_diet12 = subset(data4a, subset = diet==1 | diet==2)
diet1 = subset(data4a_diet12[1], subset = diet==1)[,1]
diet2 = subset(data4a_diet12[1], subset = diet==2)[,1]
kruskal.test(list(g1=diet1, g2=diet2))
#P-vrednost=0,9624 je večja od alfa => ne moremo zavrniti H0 => ni trdnih dokazov, da razredi vplivajo na rezultat