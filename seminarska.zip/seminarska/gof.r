# a function for testing the hypothesis of normal distribution
gof = function(sample,alfa){
  # number of frequency classes
	n=length(sample)
	k=round(sqrt(n))
	xp=mean(sample)
	s=sd(sample)
	# compute the number of the elements of the sample in individual frequency classes
	bounds=seq(min(sample),max(sample),length=k+1)
	freq.sample=cut(sample,bounds)
	table(freq.sample)
	freq.sample.vec=vector()
	for(i in 1:k) freq.sample.vec[i]<-table(freq.sample)[[i]]
	# compute the expected frequencies according to normal distribution
	freq.ex=vector()
	freq.ex[1]=pnorm(bounds[2],xp,s)*n
	freq.ex[k]=pnorm(bounds[k],xp,s,lower.tail=FALSE)*n
	for(i in 2:(k-1)) freq.ex[i]<-(pnorm(bounds[i+1],xp,s)-pnorm(bounds[i],xp,s))*n
	# compute the value of test statistic for a given sample
	X2.sample=sum(((freq.sample.vec-freq.ex)^2)/freq.ex)
	print(paste("Sample test statistic:",X2.sample))
	# compute the upper quartile of the chi-square distribution
	p=2
	df=k-p-1
	X2.quartile=qchisq(alfa,df,lower.tail=FALSE)
	print(paste("Comparative quartile:",X2.quartile))
	return(list(df=df,statistic=X2.sample,quantile=X2.quartile))
}
