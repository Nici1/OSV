
################################## NALOGA 11 - 56 ################################
# a)
weight = c(165, 167, 180, 155, 212, 175, 190, 210, 200, 149, 158, 169, 170, 172, 159, 168, 174, 183, 215, 195, 180, 143, 240, 235, 192, 187)
b_pressure = c(130, 133, 150, 128, 151, 146, 150, 140, 148, 125, 133, 135, 150, 153, 128, 132, 149, 158, 150, 163, 156, 124, 170, 165, 160, 159)


# Način 1
w_mean = mean(weight)
w_mean
plot(weight, b_pressure)

bpressure_mean = mean(b_pressure)
bpressure_mean

S_xx = 0
for (x in weight){
  #print(x-w_mean)
  S_xx = S_xx + (x - w_mean)^2
}
S_xx

S_xy = 0
for(i in 1:length(b_pressure)){
  S_xy = S_xy + b_pressure[i]*(weight[i] - w_mean)
}
S_xy

B_1 = S_xy / S_xx
B_0 = bpressure_mean - B_1 * w_mean


x = seq(min(weight)/2, 2*max(weight))
lines(x,B_0 + x*B_1, type = 'l', col = 'green', lwd = 4)


B_0
B_1
x

# Način 2
plot(weight, b_pressure, xlab = "Blood pressure", ylab = "Weight")
reg.line = lm(b_pressure ~ weight) 
reg.line$coefficients 
abline(reg.line, col = "red")



# b)

s = summary(reg.line)

s #gledamo tista p-vrednost ki je za naklon, delamo  test za naklon

coef = s$coefficients
coef[2,4] #P-vrednost za test znacilnosti regresije
#P-vrednost je manjsa kot 0.05 => hipotezo H0 zavrnemo, obstaja linearna odvisnost => model je smiselen
# P< alpha => linearen model je statisticno znacilen (da je linearna regresija)


# c)
# Način 1
cor.test(weight, b_pressure)

# Način 2
r1 = 0
for(i in 1:length(b_pressure)){
  r1 = r1 + (b_pressure[i] - bpressure_mean)*(weight[i] - w_mean)
}

r2 = 0
for(i in 1:length(b_pressure)){
  r2 = r2 + (weight[i] - w_mean)^2
}

r3 = 0
for(i in 1:length(b_pressure)){
  r3 = r3 + (b_pressure[i] - bpressure_mean)^2
}

r = r1 / (sqrt(r2) * sqrt(r3))

r



################################## NALOGA 12 - 64 ################################

prec = read.table("EX12_66.TXT")
x3 = prec[,5] # fuel flow rate
x4 = prec[,6] # pressure
x5 = prec[,7] # exhaust temperature
y = prec[,2] # thrust


MLR = lm(y ~ x3 + x4 + x5) #ne pomeni da se dejansko sestejeta

coef = round(MLR$coefficients,2)
coef
print(paste("THRUST = ", coef[1], "+", coef[2], "* FUEL FLOW RATE + ", coef[3], "* PRESSURE", "+", coef[4], "* EXHAUST PRESSURE"))

#Napoved za thrust
coef[1] + coef[2]*1670 + coef[3]*170 + coef[4]*1589




summary(MLR)
